package com.example.paypal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
